//  main.m
//  MacApp
//
//  Olaf van Houten
//  10424598
//  olaf.ajax@hotmail.com
//
//  Created by Olaf Van Houten on 01/09/14.
//  Copyright (c) 2014 Olaf van Houten. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog(@"Hello, FirstApp!");
        
    }
    return 0;
}

