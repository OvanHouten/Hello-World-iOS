//
//  main.m
//  IphoneApp
//
//  Olaf van Houten
//  10424598
//  olaf.ajax@hotmail.com
//
//  Created by Olaf Van Houten on 01/09/14.
//  Copyright (c) 2014 Olaf van Houten. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
